# LANA_report_202607
This repository contains the *Project LANA Interim Report on IUT Theory* (file name: `LANA_report_2026.pdf`), which serves as both an interim report for Project LANA and a survey of IUT theory. It was released simultaneously with the press conference *LANA Interim Report July 2026*, held on Friday, July 17, in Higashi-Ginza, Tokyo.
The PDF version of the document is located in the “pdf” branch. You can view it directly by clicking the filename or by visiting `https://github.com/katobungen/LANA_report_202607/blob/pdf/LANA_report_202607.pdf`
You can also download the PDF file by clicking the download icon in the upper-right corner of the document.
The document is expected to be updated as needed.
